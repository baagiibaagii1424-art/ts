import { useCart } from "@/contexts/CartContext";
import { X, Minus, Plus } from "lucide-react";
import { Link } from "react-router-dom";

const CartDrawer = () => {
  const { items, isCartOpen, setIsCartOpen, removeItem, updateQuantity, totalPrice, totalItems } = useCart();

  if (!isCartOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-foreground/30 z-50 animate-fade-in"
        onClick={() => setIsCartOpen(false)}
      />

      {/* Drawer */}
      <div className="fixed top-0 right-0 h-full w-full max-w-md bg-background z-50 shadow-2xl flex flex-col"
        style={{ animation: "slide-in-right 0.4s ease-out" }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-6 border-b border-border">
          <h2 className="font-serif text-xl font-light">
            Your Bag ({totalItems})
          </h2>
          <button
            onClick={() => setIsCartOpen(false)}
            className="p-1 hover:opacity-60 transition-opacity"
            aria-label="Close cart"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <p className="font-serif text-lg font-light mb-3">Your bag is empty</p>
              <p className="text-sm text-muted-foreground font-light mb-8">
                Discover our limited collection
              </p>
              <Link
                to="/shop"
                onClick={() => setIsCartOpen(false)}
                className="px-8 py-3 bg-primary text-primary-foreground text-xs tracking-luxury uppercase font-light hover:opacity-90 transition-opacity"
              >
                Shop Now
              </Link>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={`${item.product.id}-${item.size}`}
                className="flex gap-4"
              >
                <Link
                  to={`/product/${item.product.id}`}
                  onClick={() => setIsCartOpen(false)}
                  className="w-20 h-28 flex-shrink-0"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-full h-full object-cover"
                  />
                </Link>
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-serif text-sm font-light">{item.product.name}</h3>
                    <p className="text-xs text-muted-foreground font-light mt-1">
                      Size: {item.size}
                    </p>
                    <p className="text-sm font-light mt-1">
                      €{item.product.price.toLocaleString()}
                    </p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() =>
                          updateQuantity(item.product.id, item.size, item.quantity - 1)
                        }
                        className="p-1 hover:opacity-60 transition-opacity"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs w-4 text-center">{item.quantity}</span>
                      <button
                        onClick={() =>
                          updateQuantity(item.product.id, item.size, item.quantity + 1)
                        }
                        className="p-1 hover:opacity-60 transition-opacity"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                    <button
                      onClick={() => removeItem(item.product.id, item.size)}
                      className="text-xs text-muted-foreground underline hover:text-foreground transition-colors"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="px-6 py-6 border-t border-border space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs tracking-luxury uppercase text-muted-foreground">
                Total
              </span>
              <span className="font-serif text-lg font-light">
                €{totalPrice.toLocaleString()}
              </span>
            </div>
            <button className="w-full py-4 bg-primary text-primary-foreground text-xs tracking-luxury uppercase font-light hover:opacity-90 transition-opacity">
              Proceed to Checkout
            </button>
            <p className="text-xs text-center text-muted-foreground font-light">
              Complimentary shipping on all orders
            </p>
          </div>
        )}
      </div>
    </>
  );
};

export default CartDrawer;

import { Link } from "react-router-dom";
import { Product } from "@/lib/products";

interface ProductCardProps {
  product: Product;
  index?: number;
}

const ProductCard = ({ product, index = 0 }: ProductCardProps) => {
  return (
    <Link
      to={`/product/${product.id}`}
      className="group block animate-fade-up"
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <div className="hover-zoom aspect-[3/4] mb-5">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover"
          loading="lazy"
        />
      </div>
      <div className="space-y-2">
        <h3 className="font-serif text-lg md:text-xl font-light tracking-wide group-hover:opacity-70 transition-opacity">
          {product.name}
        </h3>
        <p className="text-sm font-light text-muted-foreground tracking-wider">
          €{product.price.toLocaleString()}
        </p>
        {product.stockLeft <= 5 && (
          <p className="text-xs tracking-luxury uppercase text-accent">
            Only {product.stockLeft} left
          </p>
        )}
      </div>
    </Link>
  );
};

export default ProductCard;

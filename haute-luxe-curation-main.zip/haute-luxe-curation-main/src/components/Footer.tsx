import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="px-6 md:px-12 lg:px-20 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-8">
          <div>
            <h3 className="font-serif text-2xl font-light tracking-luxury mb-6">MAISON ÉLARA</h3>
            <p className="text-sm font-light leading-relaxed opacity-70 max-w-xs">
              Minimal pieces. Maximum elegance. Timeless luxury for the refined woman.
            </p>
          </div>

          <div>
            <h4 className="text-xs tracking-luxury uppercase mb-6 opacity-50">Navigate</h4>
            <div className="space-y-3">
              {["Shop", "About", "Contact"].map((item) => (
                <Link
                  key={item}
                  to={`/${item.toLowerCase()}`}
                  className="block text-sm font-light opacity-70 hover:opacity-100 transition-opacity"
                >
                  {item}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-xs tracking-luxury uppercase mb-6 opacity-50">Follow</h4>
            <div className="space-y-3">
              {["Instagram", "Pinterest", "LinkedIn"].map((item) => (
                <a
                  key={item}
                  href="#"
                  className="block text-sm font-light opacity-70 hover:opacity-100 transition-opacity"
                >
                  {item}
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-primary-foreground/10">
          <p className="text-xs font-light opacity-40 tracking-wider">
            © 2026 Maison Élara. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

import { useState } from "react";
import Layout from "@/components/Layout";
import ProductCard from "@/components/ProductCard";
import { products, categories, colors } from "@/lib/products";

const Shop = () => {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedColor, setSelectedColor] = useState("All");

  const filtered = products.filter((p) => {
    const catMatch = selectedCategory === "All" || p.category === selectedCategory;
    const colorMatch = selectedColor === "All" || p.color === selectedColor;
    return catMatch && colorMatch;
  });

  return (
    <Layout>
      <section className="px-6 md:px-12 lg:px-20 py-12 md:py-20">
        <h1 className="font-serif text-4xl md:text-5xl font-light mb-4 animate-fade-up">
          The Collection
        </h1>
        <p className="text-sm font-light text-muted-foreground tracking-wider mb-12 animate-fade-up animate-delay-100">
          {products.length} limited pieces
        </p>

        {/* Filters */}
        <div className="flex flex-wrap gap-8 mb-16 animate-fade-up animate-delay-200">
          <div>
            <span className="text-xs tracking-luxury uppercase text-muted-foreground block mb-3">
              Category
            </span>
            <div className="flex flex-wrap gap-3">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`text-xs tracking-wider uppercase px-4 py-2 border transition-all duration-300 ${
                    selectedCategory === cat
                      ? "bg-primary text-primary-foreground border-primary"
                      : "border-border text-muted-foreground hover:border-foreground hover:text-foreground"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
          <div>
            <span className="text-xs tracking-luxury uppercase text-muted-foreground block mb-3">
              Color
            </span>
            <div className="flex flex-wrap gap-3">
              {colors.map((color) => (
                <button
                  key={color}
                  onClick={() => setSelectedColor(color)}
                  className={`text-xs tracking-wider uppercase px-4 py-2 border transition-all duration-300 ${
                    selectedColor === color
                      ? "bg-primary text-primary-foreground border-primary"
                      : "border-border text-muted-foreground hover:border-foreground hover:text-foreground"
                  }`}
                >
                  {color}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Products grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12">
          {filtered.map((product, i) => (
            <ProductCard key={product.id} product={product} index={i} />
          ))}
        </div>

        {filtered.length === 0 && (
          <p className="text-center text-muted-foreground font-light py-20">
            No pieces match your selection.
          </p>
        )}
      </section>
    </Layout>
  );
};

export default Shop;

import { useParams, Link } from "react-router-dom";
import { useState } from "react";
import Layout from "@/components/Layout";
import { products } from "@/lib/products";
import { useCart } from "@/contexts/CartContext";
import { ArrowLeft, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const ProductDetail = () => {
  const { id } = useParams();
  const product = products.find((p) => p.id === id);
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [sizeError, setSizeError] = useState(false);
  const [added, setAdded] = useState(false);
  const { addItem } = useCart();
  const { toast } = useToast();

  if (!product) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <p className="font-serif text-2xl font-light">Piece not found.</p>
        </div>
      </Layout>
    );
  }

  const handleAddToBag = () => {
    if (!selectedSize) {
      setSizeError(true);
      return;
    }
    setSizeError(false);
    addItem(product, selectedSize);
    setAdded(true);
    toast({
      title: "Added to bag",
      description: `${product.name} — Size ${selectedSize}`,
    });
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <Layout>
      <div className="px-6 md:px-12 lg:px-20 py-8">
        <Link
          to="/shop"
          className="inline-flex items-center gap-2 text-xs tracking-luxury uppercase text-muted-foreground hover:text-foreground transition-colors mb-8"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Collection
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-0 lg:gap-16 px-6 md:px-12 lg:px-20 pb-24">
        {/* Image */}
        <div className="aspect-[3/4] mb-8 lg:mb-0 animate-fade-up">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Details */}
        <div className="flex flex-col justify-center animate-fade-up animate-delay-200">
          <h1 className="font-serif text-3xl md:text-4xl lg:text-5xl font-light mb-4">
            {product.name}
          </h1>
          <p className="text-lg font-light text-muted-foreground tracking-wider mb-8">
            €{product.price.toLocaleString()}
          </p>

          <p className="text-sm font-light leading-relaxed text-muted-foreground mb-10 max-w-md">
            {product.description}
          </p>

          {/* Size selector */}
          <div className="mb-8">
            <span className="text-xs tracking-luxury uppercase text-muted-foreground block mb-4">
              Select Size
              {sizeError && (
                <span className="text-destructive ml-3 normal-case tracking-normal">
                  — Please select a size
                </span>
              )}
            </span>
            <div className="flex gap-3">
              {product.sizes.map((size) => (
                <button
                  key={size}
                  onClick={() => {
                    setSelectedSize(size);
                    setSizeError(false);
                  }}
                  className={`w-12 h-12 flex items-center justify-center text-xs tracking-wider border transition-all duration-300 ${
                    selectedSize === size
                      ? "bg-primary text-primary-foreground border-primary"
                      : "border-border text-foreground hover:border-foreground"
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Stock indicator */}
          {product.stockLeft <= 10 && (
            <p className="text-xs tracking-luxury uppercase text-accent mb-6">
              Limited — Only {product.stockLeft} pieces remaining
            </p>
          )}

          {/* Add to bag */}
          <button
            onClick={handleAddToBag}
            className={`w-full md:w-auto px-16 py-4 text-xs tracking-luxury uppercase font-light transition-all duration-300 mb-12 flex items-center justify-center gap-2 ${
              added
                ? "bg-accent text-accent-foreground"
                : "bg-primary text-primary-foreground hover:opacity-90"
            }`}
          >
            {added ? (
              <>
                <Check className="w-4 h-4" />
                Added
              </>
            ) : (
              "Add to Bag"
            )}
          </button>

          {/* Details accordion */}
          <div className="space-y-6 border-t border-border pt-8">
            <div>
              <h4 className="text-xs tracking-luxury uppercase mb-3">Fabric</h4>
              <p className="text-sm font-light text-muted-foreground">{product.fabric}</p>
            </div>
            <div className="border-t border-border pt-6">
              <h4 className="text-xs tracking-luxury uppercase mb-3">Craftsmanship</h4>
              <p className="text-sm font-light text-muted-foreground leading-relaxed">{product.story}</p>
            </div>
            <div className="border-t border-border pt-6">
              <h4 className="text-xs tracking-luxury uppercase mb-3">Care</h4>
              <p className="text-sm font-light text-muted-foreground">
                Professional dry clean only. Store on a padded hanger in a breathable garment bag.
              </p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ProductDetail;

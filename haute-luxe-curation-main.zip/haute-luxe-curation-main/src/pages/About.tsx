import Layout from "@/components/Layout";
import aboutHero from "@/assets/about-hero.jpg";
import productKnit from "@/assets/product-knit.jpg";

const About = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="relative h-[60vh] md:h-[70vh] overflow-hidden">
        <img
          src={aboutHero}
          alt="Our atelier"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-foreground/30" />
        <div className="relative z-10 flex items-end h-full px-6 md:px-12 lg:px-20 pb-12 md:pb-20">
          <h1 className="font-serif text-4xl md:text-6xl font-light text-primary-foreground animate-fade-up">
            Our Story
          </h1>
        </div>
      </section>

      {/* Philosophy */}
      <section className="px-6 md:px-12 lg:px-20 py-24 md:py-32 max-w-4xl">
        <h2 className="font-serif text-3xl md:text-4xl font-light mb-8 animate-fade-up">
          We believe in less.
        </h2>
        <div className="space-y-6 text-sm md:text-base font-light leading-relaxed text-muted-foreground animate-fade-up animate-delay-200">
          <p>
            Maison Élara was born from a simple conviction: the most beautiful wardrobe 
            is the most considered one. We create a limited number of pieces each season — 
            not because we can't make more, but because restraint is the ultimate luxury.
          </p>
          <p>
            Every garment begins with the fabric. We source exclusively from heritage mills 
            in Italy, Scotland, and Japan — materials so exceptional they command respect 
            before a single stitch is made. Our cashmere comes from the Gobi Desert, our 
            silk from Lake Como, our linen from Belfast.
          </p>
          <p>
            We don't follow trends. We don't produce seasons in the traditional sense. 
            We create pieces that will be as relevant in ten years as they are today. 
            This is slow fashion in its purest form — clothing made to be treasured, 
            not consumed.
          </p>
        </div>
      </section>

      {/* Image + text */}
      <section className="grid grid-cols-1 md:grid-cols-2">
        <div className="flex flex-col justify-center px-8 md:px-16 lg:px-24 py-16 md:py-0 bg-secondary order-2 md:order-1">
          <h2 className="font-serif text-3xl md:text-4xl font-light mb-6">
            Crafted by Hand
          </h2>
          <p className="text-sm md:text-base font-light leading-relaxed text-muted-foreground max-w-md">
            Our atelier in Florence employs a small team of master artisans, each with 
            over twenty years of experience. They bring an uncompromising attention to 
            detail that machines simply cannot replicate — hand-rolled hems, invisible 
            seams, and finishes that reveal themselves only upon the closest inspection.
          </p>
        </div>
        <div className="aspect-square order-1 md:order-2">
          <img
            src={productKnit}
            alt="Craftsmanship detail"
            className="w-full h-full object-cover"
          />
        </div>
      </section>

      {/* Values */}
      <section className="px-6 md:px-12 lg:px-20 py-24 md:py-32">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-16">
          {[
            {
              title: "Limited Editions",
              text: "Each piece is produced in quantities of no more than fifty. When they're gone, they're gone.",
            },
            {
              title: "Sustainable Luxury",
              text: "We produce less, so the planet can breathe more. Every material is responsibly sourced and fully traceable.",
            },
            {
              title: "Timeless Design",
              text: "Our pieces are designed to transcend seasons. Buy once, wear forever. This is the antidote to fast fashion.",
            },
          ].map((item, i) => (
            <div key={item.title} className="animate-fade-up" style={{ animationDelay: `${i * 150}ms` }}>
              <h3 className="font-serif text-xl md:text-2xl font-light mb-4">{item.title}</h3>
              <p className="text-sm font-light text-muted-foreground leading-relaxed">{item.text}</p>
            </div>
          ))}
        </div>
      </section>
    </Layout>
  );
};

export default About;

import { useState } from "react";
import Layout from "@/components/Layout";

const Contact = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <Layout>
      <section className="px-6 md:px-12 lg:px-20 py-16 md:py-24">
        <div className="max-w-2xl">
          <h1 className="font-serif text-4xl md:text-5xl font-light mb-4 animate-fade-up">
            Get in Touch
          </h1>
          <p className="text-sm font-light text-muted-foreground leading-relaxed mb-16 animate-fade-up animate-delay-100">
            We'd love to hear from you. Whether you have a question about sizing, 
            craftsmanship, or a private appointment at our atelier — we're here.
          </p>

          {submitted ? (
            <div className="py-20 text-center animate-fade-up">
              <p className="font-serif text-2xl font-light mb-3">Thank you.</p>
              <p className="text-sm font-light text-muted-foreground">
                We'll respond within 24 hours.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-8 animate-fade-up animate-delay-200">
              <div>
                <label className="text-xs tracking-luxury uppercase text-muted-foreground block mb-3">
                  Name
                </label>
                <input
                  type="text"
                  required
                  className="w-full bg-transparent border-b border-border py-3 text-sm font-light focus:outline-none focus:border-foreground transition-colors"
                />
              </div>
              <div>
                <label className="text-xs tracking-luxury uppercase text-muted-foreground block mb-3">
                  Email
                </label>
                <input
                  type="email"
                  required
                  className="w-full bg-transparent border-b border-border py-3 text-sm font-light focus:outline-none focus:border-foreground transition-colors"
                />
              </div>
              <div>
                <label className="text-xs tracking-luxury uppercase text-muted-foreground block mb-3">
                  Message
                </label>
                <textarea
                  required
                  rows={5}
                  className="w-full bg-transparent border-b border-border py-3 text-sm font-light focus:outline-none focus:border-foreground transition-colors resize-none"
                />
              </div>
              <button
                type="submit"
                className="px-12 py-4 bg-primary text-primary-foreground text-xs tracking-luxury uppercase font-light hover:opacity-90 transition-opacity duration-300"
              >
                Send Message
              </button>
            </form>
          )}
        </div>

        {/* Contact info */}
        <div className="mt-24 pt-16 border-t border-border grid grid-cols-1 md:grid-cols-3 gap-12">
          <div>
            <h4 className="text-xs tracking-luxury uppercase text-muted-foreground mb-3">Atelier</h4>
            <p className="text-sm font-light leading-relaxed">
              Via dei Calzaiuoli, 18<br />
              50122 Florence, Italy
            </p>
          </div>
          <div>
            <h4 className="text-xs tracking-luxury uppercase text-muted-foreground mb-3">Email</h4>
            <p className="text-sm font-light">
              atelier@maisonelara.com
            </p>
          </div>
          <div>
            <h4 className="text-xs tracking-luxury uppercase text-muted-foreground mb-3">Social</h4>
            <div className="space-y-2">
              {["Instagram", "Pinterest", "LinkedIn"].map((s) => (
                <a key={s} href="#" className="block text-sm font-light hover:opacity-60 transition-opacity">
                  {s}
                </a>
              ))}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Contact;

import { Link } from "react-router-dom";
import Layout from "@/components/Layout";
import ProductCard from "@/components/ProductCard";
import { products } from "@/lib/products";
import heroImage from "@/assets/hero-main.jpg";
import aboutHero from "@/assets/about-hero.jpg";

const Index = () => {
  const featured = products.slice(0, 3);

  return (
    <Layout>
      {/* Hero */}
      <section className="relative h-[90vh] md:h-screen overflow-hidden">
        <img
          src={heroImage}
          alt="Luxury cashmere fabric"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-foreground/20" />
        <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-6">
          <h1 className="font-serif text-4xl md:text-6xl lg:text-7xl font-light text-primary-foreground animate-fade-up leading-tight max-w-4xl">
            Timeless Pieces for a<br />Refined Woman.
          </h1>
          <p className="mt-6 text-sm md:text-base font-light text-primary-foreground/80 tracking-luxury uppercase animate-fade-up animate-delay-200">
            Autumn / Winter 2026
          </p>
          <Link
            to="/shop"
            className="mt-10 px-10 py-4 border border-primary-foreground/60 text-primary-foreground text-xs tracking-luxury uppercase font-light hover:bg-primary-foreground hover:text-foreground transition-all duration-500 animate-fade-up animate-delay-400"
          >
            Discover the Collection
          </Link>
        </div>
      </section>

      {/* Brand statement */}
      <section className="py-24 md:py-32 px-6 md:px-12 lg:px-20 text-center">
        <p className="font-serif text-2xl md:text-3xl lg:text-4xl font-light leading-relaxed max-w-3xl mx-auto animate-fade-up">
          Minimal pieces. Maximum elegance.<br />
          Rare and refined — crafted for those who understand<br />
          that true luxury whispers.
        </p>
      </section>

      {/* Featured Collection */}
      <section className="px-6 md:px-12 lg:px-20 pb-24 md:pb-32">
        <div className="flex items-center justify-between mb-12">
          <h2 className="font-serif text-2xl md:text-3xl font-light tracking-wide">
            The Limited Collection
          </h2>
          <Link
            to="/shop"
            className="text-xs tracking-luxury uppercase font-light opacity-60 hover:opacity-100 transition-opacity"
          >
            View All
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
          {featured.map((product, i) => (
            <ProductCard key={product.id} product={product} index={i} />
          ))}
        </div>
      </section>

      {/* Editorial section */}
      <section className="grid grid-cols-1 md:grid-cols-2">
        <div className="aspect-square md:aspect-auto">
          <img
            src={aboutHero}
            alt="Atelier"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex flex-col justify-center px-8 md:px-16 lg:px-24 py-16 md:py-0 bg-secondary">
          <h2 className="font-serif text-3xl md:text-4xl font-light mb-6 animate-fade-up">
            The Art of<br />Slow Fashion
          </h2>
          <p className="text-sm md:text-base font-light leading-relaxed text-muted-foreground mb-8 max-w-md">
            Every piece in our collection is made in limited quantities by master artisans. 
            We believe in clothing that lasts — in quality, in beauty, and in meaning.
          </p>
          <Link
            to="/about"
            className="text-xs tracking-luxury uppercase font-light border-b border-foreground/30 pb-1 self-start hover:border-foreground transition-colors"
          >
            Our Story
          </Link>
        </div>
      </section>
    </Layout>
  );
};

export default Index;

import productCoat from "@/assets/product-coat.jpg";
import productDress from "@/assets/product-dress.jpg";
import productBlouse from "@/assets/product-blouse.jpg";
import productTrousers from "@/assets/product-trousers.jpg";
import productKnit from "@/assets/product-knit.jpg";
import productBlazer from "@/assets/product-blazer.jpg";

export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  color: string;
  sizes: string[];
  image: string;
  description: string;
  fabric: string;
  story: string;
  stockLeft: number;
}

export const products: Product[] = [
  {
    id: "cashmere-overcoat",
    name: "The Cashmere Overcoat",
    price: 2850,
    category: "Outerwear",
    color: "Camel",
    sizes: ["XS", "S", "M", "L"],
    image: productCoat,
    description: "A timeless overcoat crafted from the finest Mongolian cashmere. Relaxed silhouette with hand-finished seams.",
    fabric: "100% Mongolian Cashmere, Silk Lining",
    story: "Each coat requires over 40 hours of hand-finishing by master artisans in our Florence atelier.",
    stockLeft: 8,
  },
  {
    id: "silk-evening-dress",
    name: "The Silk Evening Dress",
    price: 3200,
    category: "Dresses",
    color: "Black",
    sizes: ["XS", "S", "M"],
    image: productDress,
    description: "An elegant floor-length silk dress with a sculpted bodice and flowing skirt. Designed for extraordinary evenings.",
    fabric: "100% Mulberry Silk Charmeuse",
    story: "Inspired by 1950s haute couture, this dress is cut from a single bolt of the world's finest silk.",
    stockLeft: 4,
  },
  {
    id: "ivory-silk-blouse",
    name: "The Ivory Silk Blouse",
    price: 890,
    category: "Tops",
    color: "Ivory",
    sizes: ["XS", "S", "M", "L"],
    image: productBlouse,
    description: "A refined silk blouse with mother-of-pearl buttons and French seams. The essence of quiet luxury.",
    fabric: "100% Italian Silk Crêpe de Chine",
    story: "Woven in Como, Italy, this silk catches light in a way that only the finest fibers can.",
    stockLeft: 12,
  },
  {
    id: "tailored-wool-trousers",
    name: "The Tailored Wool Trousers",
    price: 1150,
    category: "Bottoms",
    color: "Brown",
    sizes: ["XS", "S", "M", "L", "XL"],
    image: productTrousers,
    description: "Impeccably tailored wide-leg trousers in virgin wool. A foundation piece for the considered wardrobe.",
    fabric: "100% Italian Virgin Wool",
    story: "Cut to drape perfectly, these trousers are the result of 12 prototype iterations to achieve the ideal silhouette.",
    stockLeft: 6,
  },
  {
    id: "cashmere-ribbed-knit",
    name: "The Ribbed Cashmere Knit",
    price: 1480,
    category: "Tops",
    color: "Beige",
    sizes: ["S", "M", "L"],
    image: productKnit,
    description: "A luxuriously soft ribbed knit in two-ply cashmere. Effortless warmth with impeccable structure.",
    fabric: "100% Two-Ply Cashmere",
    story: "Knitted slowly on heritage machines in Scotland, each piece takes three days to complete.",
    stockLeft: 9,
  },
  {
    id: "structured-linen-blazer",
    name: "The Linen Blazer",
    price: 1650,
    category: "Outerwear",
    color: "Ivory",
    sizes: ["XS", "S", "M", "L"],
    image: productBlazer,
    description: "A structured yet relaxed blazer in heavyweight Irish linen. Refined simplicity for every occasion.",
    fabric: "100% Irish Linen, Cotton Lining",
    story: "The linen is woven in a family-owned mill in Belfast that has been operating since 1880.",
    stockLeft: 7,
  },
];

export const categories = ["All", "Outerwear", "Dresses", "Tops", "Bottoms"];
export const colors = ["All", "Camel", "Black", "Ivory", "Brown", "Beige"];
